module.exports = {
  secret: 'rnpdbekspwkrnvnsuwquivhaokspsast',
}
