```bash
> yarn add mysql2 express crypto-js cors jsonwebtoken multer
```
